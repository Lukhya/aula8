package com.uninter.aulaweb.demoweb.dao;

import org.springframework.stereotype.Repository;

import com.uninter.aulaweb.demoweb.domain.Palavra;
@Repository
public class PalavraDaoImpl extends AbstractDao<Palavra, Long> implements PalavraDao {
	
	
}
